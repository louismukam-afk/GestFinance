<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Salle extends Model
{
    use HasFactory;

    protected $table = 'salles';

    protected $fillable = [
        'nom_salle',
        'code_salle',
        'capacite',
        'statut',
        'id_user',
    ];
}
