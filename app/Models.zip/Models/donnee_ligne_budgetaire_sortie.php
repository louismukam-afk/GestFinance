<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class donnee_ligne_budgetaire_sortie extends Model
{
    use HasFactory;
}
