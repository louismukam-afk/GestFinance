<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class element_ligne_budgetaire_sortie extends Model
{
    use HasFactory;
}
