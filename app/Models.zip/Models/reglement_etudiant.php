<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class reglement_etudiant extends Model
{
    use HasFactory;

    protected $table='reglement_etudiants';
    public $timestamps=true;

    protected  $fillable = [
        'id_cycle', 'id_niveau', 'id_caisse',
        'id_banque', 'id_filiere', 'id_scolarite',
        'id_frais', 'id_tranche_scolarite',
        'id_specialite', 'id_etudiant', 'id_budget',
       'id_ligne_budgetaire_entree',
       'id_element_ligne_budgetaire_entree',
       'id_donnee_ligne_budgetaire_entree',
       'montant_reglement',
       'numero_reglement',
       'date_reglement',
      'id_annee_academique',
       'type_reglement',
       'id_user',
       'id_donnee_budgetaire_entree',
       'motif_reglement',
       'id_entite',
       'lettre',
        'id_facture_etudiant',
        'type_versement'
    ];
    public function annee_academique(){
        return $this->belongsTo(annee_academique::class,'id_annee_academique');
    }

    public function entite(){
        return $this->belongsTo(entite::class,'id_entite')->withDefault([
            'logo' => 'uploads/images/1759420569_logo.jpg',
            'nom_entite' => '—',
            'telephone' => '—'
        ]);
    }
    public function donnee_budgetaire_entree(){
        return $this->belongsTo(donnee_budgetaire_entree::class,'id_donnee_budgetaire_entree');
    }
    public function cycles(){
        return $this->belongsTo(cycle::class,'id_cycle');
    }
    public function niveaux(){
        return $this->belongsTo(niveau::class,'id_niveau');
    }
    public function user(){
        return $this->belongsTo(User::class,'id_user');
    }
    public function filieres(){
        return $this->belongsTo(filiere::class,'id_filiere');
    }
    public function scolarites(){
        return $this->belongsTo(scolarite::class,'id_scolarite');
    }
    public function frais(){
        return $this->belongsTo(frais::class,'id_frais');
    }
    public function tranche_scolarites(){
        return $this->belongsTo(tranche_scolarite::class,'id_tranche_scolarite');
    }
    public function specialites(){
        return $this->belongsTo(specialite::class,'id_specialite');
    }

    public function etudiants(){
        return $this->belongsTo(Etudiant::class,'id_etudiant');
    }
    public function budget(){
        return $this->belongsTo(Budget::class,'id_budget');
    }
    public function ligne_budgetaire_entree(){
        return $this->belongsTo(ligne_budgetaire_Entree::class,'id_ligne_budgetaire_entree');
    }
    public function element_ligne_budgetaire_entree(){
        return $this->belongsTo(element_ligne_budgetaire_entree::class,'id_element_ligne_budgetaire_entree');
    }
    public function donnee_ligne_budgetaire_entree(){
        return $this->belongsTo(donnee_ligne_budgetaire_entree::class,'id_donnee_ligne_budgetaire_entree');
    }
    public function facture_etudiants(){
        return $this->belongsTo(facture_etudiant::class,'id_facture_etudiant');
    }

    public function banque(){
        return $this->belongsTo(banque::class,'id_banque');
    }
    public function caisse(){
        return $this->belongsTo(caisse::class,'id_caisse');
    }


}
