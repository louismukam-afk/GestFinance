<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('ligne_budgetaire_sorties', function (Blueprint $table) {
            $table->id();
            $table->string('libelle_ligne_budgetaire_sortie');
            $table->string('code_ligne_budgetaire_sortie');
            $table->string('numero_compte_ligne_budgetaire_sortie');
            $table->string('description');
            $table->date('date_creation');
            $table->integer('id_user')->default(0);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('ligne_budgetaire_sorties');
    }
};
